'use strict';

var _ = require('lodash');
var gh = require('GeoHex-node')
var rp = require('request-promise');
var ENDPOINT = 'https://0b40ebq662.execute-api.us-west-2.amazonaws.com/qa/places?';

function SightingApiHelper() { }

  
SightingApiHelper.prototype.returnGeoHexes = function(placeData){
   
  var gh_array = [];
   for (var i = 0; i < placeData.body.hits.hits.length; i++) {
     var lat = placeData.body.hits.hits[i]['_source']['location']['lat'];
     var lon = placeData.body.hits.hits[i]['_source']['location']['lon'];
     gh_array.push(gh.getZoneByLocation(lat, lon, 6).code);
   }
   return gh_array;
};

SightingApiHelper.prototype.getSightings = function(ghArray){
  

  
  var options = {
    method: 'GET',
    uri: ENDPOINT + 'gh=' + ghArray + '&sightings=1',
    resolveWithFullResponse: true,
    json: true
  };
  return rp(options);
};

  SightingApiHelper.prototype.formatSightingsData = function(sightingsData){
    var response = _.template('In the past year, with a half mile radius around those places, I count ${total} available impressions across ${unique} unique devices')({
    total: sightingsData.body.aggregations.available.value,
    unique: sightingsData.body.aggregations.uniques.value
  });

  return response;


};



	 
 module.exports = SightingApiHelper;





 